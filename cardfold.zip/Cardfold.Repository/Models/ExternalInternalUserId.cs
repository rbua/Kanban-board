﻿namespace Cardfold.Repository.Models
{
    public class ExternalInternalUserId
    {
        public string ExternalUserId { get; set; }

        public int? InternalUserId { get; set; }
    }
}
