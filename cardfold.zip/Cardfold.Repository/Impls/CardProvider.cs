﻿using Cardfold.Domain.Models;
using Cardfold.Repository.Context;
using Cardfold.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace Cardfold.Repository.Impls
{
    public class CardProvider : ICardProvider
    {
        private readonly ApplicationContext _applicationContext;
        public CardProvider(ApplicationContext applicationContext)
        {
            _applicationContext = applicationContext;
        }

        public Card<int> CreateCard(Card<int> card, int teamId)
        {
            _applicationContext.Cards.Add(card);

            var team = _applicationContext.Teams.Include(x => x.Cards).FirstOrDefault(x => x.Id == teamId);
            team.Cards.Add(card);

            _applicationContext.SaveChanges();

            return card;
        }

        public Card<int> GetCard(int cardId)
        {
            var card = _applicationContext.Cards.FirstOrDefault(x => x.Id == cardId);
            
            _applicationContext.SaveChanges();

            return card;
        }

        public Card<int> UpdateCard(Card<int> card)
        {
            var cardValue = _applicationContext.Cards
                .FirstOrDefault(x => x.Id == card.Id);

            cardValue.AssignedTo = card.AssignedTo;
            cardValue.Color = card.Color;
            cardValue.Comments = card.Comments;
            cardValue.Description = card.Description;
            cardValue.Name = card.Name;


            _applicationContext.SaveChanges();

            return cardValue;
        }

        public void DeleteCard(Card<int> card)
        {
            _applicationContext.Cards.Remove(card);

            _applicationContext.SaveChanges();
        }
    }
}
