﻿using Cardfold.Repository.Context;

namespace Cardfold.Repository.Impls
{
    public class ColumnProvider
    {
        private readonly ApplicationContext _applicationContext;

        public ColumnProvider(ApplicationContext applicationContext)
        {
            _applicationContext = applicationContext;
        }


        //public void CreateColumn(string columnName, )
        //{

        //}
    }
}
