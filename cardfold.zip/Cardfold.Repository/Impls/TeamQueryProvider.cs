﻿using Cardfold.Domain.Models;
using Cardfold.Domain.Models.Output;
using Cardfold.Repository.Interfaces;
using Dapper;
using System;
using System.Data;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Cardfold.Repository.Context;
using System.Linq;
using System.Collections.Generic;

namespace Cardfold.Repository.Impls
{
    public class TeamQueryProvider : ITeamQueryProvider
    {
        private readonly ApplicationContext _applicationContext;
        public TeamQueryProvider(ApplicationContext applicationContext)
        {
            _applicationContext = applicationContext;
        }

        public Team<int> CreateTeam(int userId, string teamName)
        {
            var team = new Team<int>
            {
                Name = teamName,
                OwnerId = userId
            };

            _applicationContext.Teams.Add(team);
            _applicationContext.SaveChanges();

            return team;
        }

        public Team<int> GetTeam(string teamId)
        {
            var team = _applicationContext.Teams.Include("Users").FirstOrDefault();
            return team;
        }

        public async void DeleteTeam(int teamId)
        {
            var team = _applicationContext.Teams.Include(x => x.Users).FirstOrDefault(x => x.Id == teamId);
            team.Users = new List<User<int>>();
            _applicationContext.SaveChanges();
        }

        public void AddUserToTeam(int userId, int teamId)
        {
            var user = _applicationContext.Users.FirstOrDefault(x => x.Id == userId);
            var team = _applicationContext.Teams.FirstOrDefault(x => x.Id == teamId);

            team.Users.Add(user);

            _applicationContext.SaveChanges();
        }
    }
}
