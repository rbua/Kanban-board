﻿using Cardfold.Domain.Models;
using Cardfold.Repository.Context;
using Cardfold.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace Cardfold.Repository.Impls
{
    public class UserIdSqlQueryProvider : IUserIdSqlQueryProvider
    {
        private readonly ApplicationContext _applicationContext;

        public UserIdSqlQueryProvider(ApplicationContext applicationContext)
        {
            _applicationContext = applicationContext;
        }

        public User<int> GetUserByEmail(string email)
        {
            return _applicationContext.Users.FirstOrDefault(x => x.Email == email);
        }

        public User<int> CreateUser(string email, string name)
        {
            var user = new User<int>
            {
                Email = email,
                Name = name,
            };

            _applicationContext.Users.Add(user);
            _applicationContext.SaveChanges();

            return user;
        }
        
        public User<int> GetUser(int userId)
        {
            return _applicationContext.Users.FirstOrDefault(x => x.Id == userId);
        }
    }
}
