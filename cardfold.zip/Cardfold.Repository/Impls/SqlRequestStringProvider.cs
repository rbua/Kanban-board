﻿using Cardfold.Repository.Interfaces;

namespace Cardfold.Repository.Impls
{
    ///<inheritdoc cref="ISqlRequestStringProvider"/>
    public class SqlRequestStringProvider : ISqlRequestStringProvider
    {
        public string GetInternalUserIdRequest => "SELECT InternalUserId FROM ExternalInternalUserIds WHERE ExternalUserId = @externalUserId";

        public string GetExternalUserIdRequest => "SELECT ExternalUserId FROM ExternalInternalUserIds WHERE InternalUserId = @internalUserId";

        public string InsertUserRequest => "INSERT INTO [User] VALUES (@userId, @email, @userName)";

        public string UpdateUserRequest => "UPDATE [User], [Email] = @email, [Name] = @userName  WHERE [Id] = @userId";

        public string GetUserRequest => "SELECT TOP 1 * from [User] WHERE [Id] = @userId";

        public string GetUserByEmailRequest => "SELECT TOP 1 [Email], [Name], [ExternalInternalUserIds].ExternalUserId AS Id FROM [User] INNER JOIN [ExternalInternalUserIds] ON [User].Id = [ExternalInternalUserIds].InternalUserId WHERE [User].Email = @userEmail";

        public string DeleteUserRequest => "DELETE FROM [User] WHERE Id = @userId";

        public string InsertExternalUserIdRequest => "INSERT INTO [ExternalInternalUserIds] OUTPUT inserted.InternalUserId VALUES (@externalUserId)";

        public string InsertTeamRequest => "INSERT INTO [Team] OUTPUT inserted.Id VALUES (@internalUserId, @teamName)";

        public string GetTeamRequest => "SELECT TOP 1 * from [Team] WHERE [Id] = @teamId";

        public string AddUserToTeamRequest => "INSERT INTO [UserTeam] VALUES (@internalUserId, @teamId)";

        public string DeleteUserTeamRelationsRequest => "DELETE FROM [UserTeam] WHERE [TeamId] = @teamId";

        public string DeleteTeamRequest => "DELETE FROM [Team] WHERE [Id] = @teamId";
    }
}
