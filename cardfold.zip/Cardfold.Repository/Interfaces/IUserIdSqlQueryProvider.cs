﻿using Cardfold.Domain.Models;

namespace Cardfold.Repository.Interfaces
{
    public interface IUserIdSqlQueryProvider
    {
        User<int> GetUserByEmail(string email);

        User<int> CreateUser(string email, string name);

        User<int> GetUser(int userId);
    }
}
