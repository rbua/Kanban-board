﻿using Cardfold.Domain.Models;

namespace Cardfold.Repository.Interfaces
{
    public interface ITeamQueryProvider
    {
        Team<int> CreateTeam(int userId, string teamName);

        Team<int> GetTeam(string teamId);

        void DeleteTeam(int teamId);

        void AddUserToTeam(int userId, int teamId);
    }
}
