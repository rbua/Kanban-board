﻿namespace Cardfold.Repository.Interfaces
{
    public interface ISqlRequestStringProvider
    {
        /// <summary>
        /// Gets internal user id by external user id.
        /// </summary>
        /// <param name="@externalUserId">Sets user`s external Id.</param>
        string GetInternalUserIdRequest { get; }

        /// <summary>
        /// Gets external user id by internal user id.
        /// </summary>
        /// <param name="@internalUserId">Sets user`s internal Id.</param>
        string GetExternalUserIdRequest { get; }

        /// <summary>
        /// Inserts user in the database.
        /// </summary>
        /// <param name="@userId">Sets user`s id. FK to ExternalInternalUserIds table.</param>
        /// <param name="@email">Sets user`s email.</param>
        /// <param name="@userName">Sets user`s name.</param>
        string InsertUserRequest { get; }

        /// <summary>
        /// Updates user in the database based on the user`s id.
        /// </summary>
        /// <param name="@userId">Sets user`s id. FK to ExternalInternalUserIds table.</param>
        /// <param name="@email">User`s email.</param>
        /// <param name="@userName">Sets user`s name.</param>
        string UpdateUserRequest { get; }

        /// <summary>
        /// Gets user from the database based on the user`s id.
        /// </summary>
        /// <param name="@userId">Sets user`s id. FK to ExternalInternalUserIds table.</param>
        string GetUserRequest { get; }

        /// <summary>
        /// Gets user from the database based on the user`s email. User.Id is already external id.
        /// </summary>
        /// <param name="@userEmail">Sets user`s email.</param>
        string GetUserByEmailRequest { get; }

        /// <summary>
        /// Deletes user from the database based on the user`s id.
        /// </summary>
        /// <param name="@userId">Sets user`s id. FK to ExternalInternalUserIds table.</param>
        string DeleteUserRequest { get; }

        /// <summary>
        /// Inserts external user id. Returns internal user id.
        /// </summary>
        /// <param name="@externalUserId">Sets external user id.</param>
        string InsertExternalUserIdRequest { get; }

        /// <summary>
        /// Inserts new team.
        /// </summary>
        /// <param name="@internalUserId">Sets user`s external Id.</param>
        /// <param name="@teamName">Sets team name.</param>
        string InsertTeamRequest { get; }

        /// <summary>
        /// Returns team.
        /// </summary>
        /// <param name="@teamId">Sets id of the team.</param>
        string GetTeamRequest { get; }

        /// <summary>
        /// Adds user to a team.
        /// </summary>
        /// <param name="@internalUserId">Sets internal user id.</param>
        /// <param name="@teamId">Id of the team.</param>
        string AddUserToTeamRequest { get; }

        /// <summary>
        /// Deletes user-team relations by the team id.
        /// </summary>
        /// <param name="@teamId">Id of the team.</param>
        string DeleteUserTeamRelationsRequest { get; }

        /// <summary>
        /// Deletes team by the team id.
        /// </summary>
        /// <param name="@teamId">Id of the team.</param>
        string DeleteTeamRequest { get; }
    }
}
