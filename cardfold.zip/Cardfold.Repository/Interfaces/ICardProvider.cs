﻿using Cardfold.Domain.Models;

namespace Cardfold.Repository.Interfaces
{
    public interface ICardProvider
    {
        Card<int> CreateCard(Card<int> card, int teamId);
        Card<int> GetCard(int cardId);
        Card<int> UpdateCard(Card<int> card);
        void DeleteCard(Card<int> card);
    }
}
