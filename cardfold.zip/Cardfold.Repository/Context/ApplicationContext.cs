﻿using Cardfold.Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace Cardfold.Repository.Context
{
    public class ApplicationContext : DbContext
    {
        public DbSet<User<int>> Users { get; set; }
        public DbSet<Team<int>> Teams { get; set; }
        public DbSet<Card<int>> Cards { get; set; }


        public ApplicationContext()
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=EPUALVIW0151\SQLEXPRESS; Integrated Security=False; Trusted_Connection=true; database=cardfold");
        }
    }
}
