﻿using Cardfold.Domain.Models;

namespace Cardfold.Services.Interfaces
{
    public interface IUserService<TId>
    {
        User<int> Create(string email, string name);
        
        User<int> Get(int userId);

        User<int> GetByEmail(string email);
    }
}
