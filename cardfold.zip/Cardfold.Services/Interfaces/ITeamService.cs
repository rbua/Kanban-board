﻿using Cardfold.Domain.Models;

namespace Cardfold.Services.Interfaces
{
    public interface ITeamService
    {
        Team<int> GetTeam(string teamId);

        void DeleteTeam(int teamId);

        Team<int> CreateTeam(int userId, string teamName);

        void AddUserToTeam(int userId, int teamId);
    }
}
