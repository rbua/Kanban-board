﻿using Cardfold.Domain.Models;
using Cardfold.Repository.Interfaces;
using Cardfold.Services.Interfaces;

namespace Cardfold.Services.Impls
{
    public class TeamService : ITeamService
    {
        private readonly ITeamQueryProvider _provider;

        public TeamService(ITeamQueryProvider provider)
        {
            _provider = provider;
        }

        public void AddUserToTeam(int userId, int teamId)
        {
            _provider.AddUserToTeam(userId, teamId);
        }

        public Team<int> CreateTeam(int userId, string teamName)
        {
            return _provider.CreateTeam(userId, teamName);
        }

        public void DeleteTeam(int teamId)
        {
            _provider.DeleteTeam(teamId);
        }

        public Team<int> GetTeam(string teamId)
        {
            return _provider.GetTeam(teamId);
        }
    }
}
