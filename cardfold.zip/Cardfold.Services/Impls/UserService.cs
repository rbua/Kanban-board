﻿using Cardfold.Domain.Models;
using Cardfold.Repository.Interfaces;
using Cardfold.Services.Interfaces;

namespace Cardfold.Services.Impls
{
    public class UserService : IUserService<int>
    {
        private readonly IUserIdSqlQueryProvider _userDbProvider;

        public UserService(IUserIdSqlQueryProvider userDbProvider)
        {
            _userDbProvider = userDbProvider;
        }

        public User<int> Create(string email, string name)
        {
            return _userDbProvider.CreateUser(email, name);
        }

        public User<int> Get(int userId)
        {
            var user = _userDbProvider.GetUser(userId);

            return user;
        }

        public User<int> GetByEmail(string email)
        {
            return _userDbProvider.GetUserByEmail(email);
        }
    }
}
