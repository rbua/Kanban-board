﻿using Cardfold.Domain.Models;
using Cardfold.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Cardfold.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TeamController : BaseController
    {
        private readonly ITeamService _teamService;

        public TeamController(ITeamService teamQueryProvider, IHttpContextAccessor httpContextAccessor)
            :base(httpContextAccessor)
        {
            _teamService = teamQueryProvider;
        }

        [HttpPost("addUserToTeam")]
        public void AddUserToTeam(int externalUserId, int teamId)
        {
            _teamService.AddUserToTeam(externalUserId, teamId);
        }

        [HttpPut]
        public Team<int> CreateTeam(int externalUserId, string teamName)
        {
            return _teamService.CreateTeam(externalUserId, teamName);
        }

        [HttpGet]
        public Team<int> GetTeam(string teamId)
        {
            return _teamService.GetTeam(teamId);
        }

        [HttpDelete]
        public void DeleteTeam(int teamId)
        {
            _teamService.DeleteTeam(teamId);
        }
    }
}
