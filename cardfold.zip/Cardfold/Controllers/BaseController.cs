﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text.Json;

namespace Cardfold.Controllers
{
    public class BaseController : ControllerBase
    {
        public string Role { get; private set; }

        public string Email { get; private set; }

        public BaseController(IHttpContextAccessor httpContextAccessor)
        {
            string authHeader = httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            var userToken = authHeader?.Substring("Bearer ".Length);
            var handler = new JwtSecurityTokenHandler();
            var token = handler.ReadToken(userToken) as JwtSecurityToken;
            
            var role = token.Payload["https://rbn.auth0.us.com/roles"];
            Role = JsonSerializer.Deserialize<List<string>>(role.ToString()).SingleOrDefault();

            if(Role == null)
            {
                Role = "user";
            }

            Email = token.Payload["email"].ToString();
        }
    }
}
