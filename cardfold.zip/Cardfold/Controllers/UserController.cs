﻿using Cardfold.Domain.Models;
using Cardfold.Repository.Interfaces;
using Cardfold.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Cardfold.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : BaseController
    {
        private readonly ITeamService _teamService;
        private readonly IUserIdSqlQueryProvider _userIdSqlQueryProvider;

        public UserController(ITeamService teamQueryProvider, 
            IHttpContextAccessor httpContextAccessor, 
            IUserIdSqlQueryProvider userIdSqlQueryProvider)
            : base(httpContextAccessor)
        {
            _teamService = teamQueryProvider;
            _userIdSqlQueryProvider = userIdSqlQueryProvider;
        }

        [HttpGet]
        public User<int> GetUserByEmail()
        {
            return _userIdSqlQueryProvider.GetUserByEmail(base.Email);
        }
    }
}
