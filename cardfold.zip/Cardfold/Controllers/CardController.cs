﻿using System.Threading.Tasks;
using Cardfold.Domain.Models;
using Cardfold.Repository.Interfaces;
using Cardfold.Services.DTOs;
using Cardfold.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TId = System.String;

namespace Cardfold.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CardController : ControllerBase
    {
        private readonly ICardService<TId> _cardService;
        private readonly ICardProvider _cardProvider;

        public CardController(ICardService<TId> cardService, ICardProvider cardProvider)
        {
            _cardService = cardService;
            _cardProvider = cardProvider;
        }

        //[Authorize(Policy = "admin-role-required")]
        [HttpPost]
        public async Task<IActionResult> CreateCard(Card<int> cardModel, int teamId)
        {
            return Ok(_cardProvider.CreateCard(cardModel, teamId));
        }

        [HttpGet]
        public async Task<IActionResult> GetCard(int cardId)
        {
            return Ok(_cardProvider.GetCard(cardId));
        }

        [HttpPut]
        public async Task<IActionResult> Update(Card<int> card)
        {
            return Ok(_cardProvider.UpdateCard(card));
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteCard(Card<int> card)
        {
            _cardProvider.DeleteCard(card);
            return NoContent();
        }
    }
}
