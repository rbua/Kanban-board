﻿using Cardfold.Domain.Models.Auth;
using Cardfold.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using RestSharp;
using System.IdentityModel.Tokens.Jwt;
using System.Text.Json;
using System.Threading.Tasks;
using System.Linq;
using Cardfold.Domain.Models;

namespace Cardfold.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUserService<int> _userService;

        private readonly string _auth0Api;
        private readonly string _clientId;
        private readonly string _clientSecret;

        public AuthController(IUserService<int> userService, IConfiguration configuration)
        {
            _userService = userService;
            _auth0Api = configuration.GetValue<string>("auth0:api");
            _clientId = configuration.GetValue<string>("auth0:client-id");
            _clientSecret = configuration.GetValue<string>("auth0:client-secret");
        }

        [AllowAnonymous]
        [HttpGet("authorize")]
        public async Task<string> Authorize([FromQuery(Name = "code")] string code)
        {
            var client = new RestClient($"https://{_auth0Api}/oauth/token");
            var request = new RestRequest(Method.POST);

            request.AddHeader("content-type", "application/x-www-form-urlencoded");
            request.AddParameter("grant_type", "authorization_code");
            request.AddParameter("client_id", _clientId);
            request.AddParameter("client_secret", _clientSecret);
            request.AddParameter("code", code);
            request.AddParameter("redirect_uri", "https://localhost:44343/api/callback");

            IRestResponse response = client.Execute(request);

            var token = JsonSerializer.Deserialize<AccessTokenObject>(response.Content);

            await RegisterUser(token.idToken);

            return token.idToken;
        }

        private async Task RegisterUser(string idToken)
        {
            var handler = new JwtSecurityTokenHandler();
            var token = handler.ReadToken(idToken) as JwtSecurityToken;

            var userEmail = token.Claims.First(claim => claim.Type == "email").Value;

            var userOutput = _userService.GetByEmail(userEmail);

            _userService.Create(userEmail, ExtractEmail(token));
        }

        private string ExtractEmail(JwtSecurityToken idToken)
        {
            var email = idToken.Payload["email"].ToString();

            return email;
        }
    }
}
