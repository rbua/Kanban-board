﻿using Cardfold.Repository.Context;
using Cardfold.Repository.Impls;
using Cardfold.Repository.Interfaces;
using Cardfold.Services.Impls;
using Cardfold.Services.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using System.Data;
using System.Data.SqlClient;

namespace Cardfold.Root
{
    public static class CompositionRoot<TId>
    {
        public static void SetupDependencies(IServiceCollection services)
        {
            services.AddTransient<IDockService<TId>, DockService<TId>>();
            services.AddTransient<IColumnService<TId>, ColumnService<TId>>();
            services.AddTransient<ICardService<TId>, CardService<TId>>();
            services.AddTransient<ICommentService<TId>, CommentService<TId>>();
            services.AddTransient<ISqlRequestStringProvider, SqlRequestStringProvider>();
            services.AddTransient<IUserService<int>, UserService>();
            services.AddTransient<ITeamService, TeamService>();
            services.AddTransient<ITeamQueryProvider, TeamQueryProvider>();
            services.AddTransient<ApplicationContext>();
            services.AddTransient<ICardProvider, CardProvider>();
            SetupSqlDependencies(services);
        }

        private static void SetupSqlDependencies(IServiceCollection services)
        {
            var dbConnectionString = @"Server=EPUALVIW0151\SQLEXPRESS; Integrated Security=False; Trusted_Connection=true; database=cardfold"; // TODO: move to appsettings, add connection pool

            services.AddTransient<IDbConnection>((sp) => new SqlConnection(dbConnectionString));

            services.AddSingleton<IUserIdSqlQueryProvider, UserIdSqlQueryProvider>();
        }
    }
}
