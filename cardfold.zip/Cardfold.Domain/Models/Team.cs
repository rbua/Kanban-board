﻿using System.Collections.Generic;

namespace Cardfold.Domain.Models
{
    public class Team<TId>
    {
        public TId Id { get; set; }

        public TId OwnerId { get; set; }

        public string Name { get; set; }

        public List<User<int>> Users { get; set; } = new List<User<int>>();
        public List<Card<int>> Cards { get; set; } = new List<Card<int>>();
    }
}
