﻿using System.Text.Json.Serialization;

namespace Cardfold.Domain.Models.Auth
{
    public class AccessTokenObject
    {
        [JsonPropertyName("access_token")]
        public string accessToken { get; set; }
        
        [JsonPropertyName("id_token")]
        public string idToken { get; set; }
    }
}
