﻿using System;

namespace Cardfold.Domain.Models
{
    public class ExceptionOutput<TResult> : ErrorOutput<TResult>
    {
        public Exception Exception { get; set; }
    }
}
