﻿namespace Cardfold.Domain.Models
{
    public interface IOutput<TResult>
    {
        bool IsSucces { get; set; }

        TResult Result { get; set; }
    }
}
