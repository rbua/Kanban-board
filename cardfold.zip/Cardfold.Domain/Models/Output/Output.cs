﻿namespace Cardfold.Domain.Models
{
    public class Output<TResult> : IOutput<TResult>
    {
        public bool IsSucces { get; set; }
        public TResult Result { get; set; }
    }
}
