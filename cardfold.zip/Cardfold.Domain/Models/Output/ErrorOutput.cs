﻿using System;

namespace Cardfold.Domain.Models
{
    public class ErrorOutput<TResult> : IOutput<TResult>
    {
        public bool IsSucces 
        { 
            get => false;
            set => throw new InvalidOperationException($"{nameof(ErrorOutput<TResult>)} should be always not successful.");  
        }
        public string ErrorMessage { get; set; }
        public TResult Result { get; set; }
    }
}
