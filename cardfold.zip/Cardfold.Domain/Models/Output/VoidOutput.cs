﻿using System;

namespace Cardfold.Domain.Models.Output
{
    public class VoidOutput : IOutput<object>
    {
        public bool IsSucces { get; set; }

        public object Result { get => null; set => throw new ArgumentException("Void output always has null result."); }
    }
}
